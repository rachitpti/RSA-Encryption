//
//  File.swift
//  RSA Encryption
//
//  Created by Rachit Prajapati on 24/04/22.
//

import Foundation
import SwiftUI


struct Introduction2: View {
    
    @State var text: String = ""
    @State var oneTime: Bool = false
    
    
    var body: some View {
        
        
        VStack(alignment: .center, spacing: 2) {
            
            Spacer()
            
            Text("The idea of an asymmetric public-private key cryptosystem is attributed to Whitfield Diffie and Martin Hellman, who published this concept in 1976. It was the complexity of the math which was not studied well at that time.")
                .font(.system(size: 40))
                .fontWeight(.semibold)
                .font(.subheadline)
                .multilineTextAlignment(.center)
            
            Spacer(minLength: 2)
            
            Text("This playground will introduce ourselves to the theory of RSA encryption and it’s working.")
                .font(.system(size: 30))
                .fontWeight(.regular)
                .font(.subheadline)
                .multilineTextAlignment(.center)
            
            Spacer(minLength: 1)
            
            Text(text)
                .font(.system(size: 40))
                .fontWeight(.semibold)
                .onAppear {
                    if !oneTime {
                        "Let's get started.".enumerated().forEach { index, character in
                            DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.1) {
                                text += String(character)
                            }
                        }
                        oneTime = true
                    }
                }
                .foregroundColor(.black)
            
            
        }
        .frame(width: UIScreen.main.bounds.width * 0.8, height: UIScreen.main.bounds.height * 0.75)
        .padding()
        .background(.ultraThinMaterial)
        .cornerRadius(40)
        
        
    }
}

struct Introduction2_Previews: PreviewProvider {
    static var previews: some View {
        Introduction2()
        
    }
}
