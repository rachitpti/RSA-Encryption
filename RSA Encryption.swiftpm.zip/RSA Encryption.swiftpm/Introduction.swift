//
//  Introduction.swift
//  RSA Encryption
//
//  Created by Rachit Prajapati on 24/04/22.
//

import Foundation
import SwiftUI

struct Introduction: View {
    var body: some View {
        
        VStack {
            Spacer(minLength: 2)
            
            Text("It was in")
                .font(.system(size: 40))
                .fontWeight(.semibold)
                .font(.subheadline)
            
            Text("1977")
                .font(.system(size: 200))
                .fontWeight(.heavy)
                .font(.largeTitle)
                .bold()
            
            VStack(alignment: .center){
                Text("Where the RSA encryption got it’s name from it's inventors:")
                    .font(.system(size: 40))
                    .fontWeight(.semibold)
                    .multilineTextAlignment(.center)
                
                HStack(spacing: 0){
                    Text("Ron ")
                        .font(.system(size: 40))
                        .fontWeight(.semibold)
                    Text("R")
                        .font(.system(size: 40))
                        .fontWeight(.heavy)
                    Text("ivest")
                        .font(.system(size: 40))
                        .fontWeight(.semibold)
                }
                
                HStack(spacing: 0) {
                    Text("Adi ")
                        .font(.system(size: 40))
                        .fontWeight(.semibold)
                    Text("S")
                        .font(.system(size: 40))
                        .fontWeight(.heavy)
                    Text("hamir")
                        .font(.system(size: 40))
                        .fontWeight(.semibold)
                    
                }
                HStack(spacing: 0) {
                    Text("Leonard ")
                        .font(.system(size: 40))
                        .fontWeight(.semibold)
                    Text("A")
                        .font(.system(size: 40))
                        .fontWeight(.heavy)
                    Text("dleman")
                        .font(.system(size: 40))
                        .fontWeight(.semibold)
                    
                }
            }
            
            Spacer(minLength: 2)
            
            Text("But here’s a catch.")
                .font(.system(size: 30))
                .fontWeight(.semibold)
        }
        .frame(width: UIScreen.main.bounds.width * 0.8, height: UIScreen.main.bounds.height * 0.75)
        .padding(20)
        .background(.ultraThinMaterial)
        .cornerRadius(40)
        
    }
}

struct Introduction_Previews: PreviewProvider {
    static var previews: some View {
        Introduction()
        
    }
}
