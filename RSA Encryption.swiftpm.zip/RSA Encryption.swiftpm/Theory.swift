//
//  Theory.swift
//  RSA Encryption
//
//  Created by Rachit Prajapati on 24/04/22.
//

import Foundation
import SwiftUI

struct Theory: View {
    
    @State var oneTime: Bool = false
    @State var opacityValue: Double = 0.0
    
    var body: some View {
        
        VStack {
            
            VStack(alignment: .center, spacing: 30) {
                
                Text("Theory time.")
                    .font(.system(size: 40))
                    .fontWeight(.bold)
                    .font(.subheadline)
                
                
                Text("RSA algorithm is asymmetric cryptography algorithm. Asymmetric actually means that it works on two different keys which are commutative to each other. i.e. Public Key and Private Key. As the name describes that the Public Key is given to everyone and Private key is kept private. As easy as it says 😄")
                    .font(.system(size: 25))
                    .fontWeight(.semibold)
                    .font(.subheadline)
                    .multilineTextAlignment(.leading)
                
                Text("Awesome. Theory's done. Now let's get a hands on with a brief of math inside it 🤩.")
                    .font(.system(size: 25))
                    .fontWeight(.semibold)
                    .font(.subheadline)
                    .multilineTextAlignment(.leading)
    
            }
            .frame(width: UIScreen.main.bounds.width * 0.8, height: UIScreen.main.bounds.height * 0.75)
            .padding()
            .background(.ultraThinMaterial)
            .cornerRadius(40)
            
        }
    }
}

struct Theory_Previews: PreviewProvider {
    static var previews: some View {
        Theory()
        
    }
}

