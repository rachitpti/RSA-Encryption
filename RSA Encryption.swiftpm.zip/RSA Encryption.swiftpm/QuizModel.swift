//
//  QuizModel.swift
//  RSA Encryption
//
//  Created by Rachit Prajapati on 25/04/22.
//

import Foundation
import SwiftUI

struct QuizModel {
    let text: String
    let answer: [String]
    let correct: Int
}


