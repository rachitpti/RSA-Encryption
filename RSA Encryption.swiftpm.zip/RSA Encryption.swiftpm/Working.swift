//
//  Working.swift
//  RSA Encryption
//
//  Created by Rachit Prajapati on 24/04/22.
//

import SwiftUI

struct Working: View {
    
    
    @State private var processMessage: String = "Finding N first. It's a product of 7 and 19. Precisely drag 7 into 19 for the answer."
    private var opacityOfProcessMessage: Double = 0.0
    @State private var productNFinal : String = "\(19)"
    @State private var productInitial : String = "\(7)"
    @State private var productTFinal : String = "18"
    @State private var offsetNFinal: CGSize = .zero
    @State private var offsetEFinal: CGSize = .zero
    @State private var location: CGPoint = CGPoint(x: 0, y: 25)
    @State private var key1Location: CGPoint = CGPoint(x: UIScreen.main.bounds.width * 0.3, y: -UIScreen.main.bounds.height * 0.01)
    @State private var eLocation: CGPoint =  CGPoint(x: UIScreen.main.bounds.width * 0.4 + 20, y: -10)
    @State private var key2Location: CGPoint = CGPoint(x: UIScreen.main.bounds.width * 0.3, y: 0)
    @State private var eFinal: String = ""
    @State var calculated: Bool = false
    @State var totientOpacity: Double = 0.0
    @State var eOpacity: Double = 1.0
    @State var textOpacity: Bool = false
    @State var center: CGPoint = CGPoint(x: UIScreen.main.bounds.width / 2, y: UIScreen.main.bounds.height / 2)
    @State private var isDone: Bool = false
    @State var key1Scale: Double = 0.0
    @State var key2Scale: Double = 0.00001
    
    var simpleDrag: some Gesture {
        DragGesture()
            .onChanged { value in
                self.location = value.location
                
            }.onEnded { value in
                productNFinal = "N = \(7 * 19)"
                if calculated == false {
                    productInitial = ""
                }
                
                if productInitial == "6" {
                    productTFinal = "T = \(6 * 18)"
                }
                
                
                
            }
    }
    
    var body: some View {
        ZStack {
            
            
            VStack(alignment: .center, spacing: 10) {
                
                Text("Let's send a message 'Hi' securely.")
                    .font(.system(size: 40))
                    .fontWeight(.heavy)
                    .font(.subheadline)
                    .multilineTextAlignment(.center)
                    .onChange(of: isDone) { _ in
                        if isDone {
                            withAnimation(.easeInOut(duration: 2)) {
                                self.textOpacity.toggle()
                            }
                        }
                    }
                    .minimumScaleFactor(0.8)
                
                
                
                VStack(alignment: .leading, spacing: 20) {
                    
                    Text("• First of all we will have to generate public key for encryption.")
                        .font(.system(size: 30))
                        .fontWeight(.semibold)
                        .animation(.easeInOut, value: textOpacity)
                        .opacity(textOpacity ? 0 : 1)
                        .minimumScaleFactor(0.5)
                    
                    
                    
                    Text("• For that we will choose 2 prime numbers A = 7 and B = 19 for learning the mechanism behind RSA algorithm.")
                        .font(.system(size: 30))
                        .fontWeight(.semibold)
                        .animation(.easeInOut, value: textOpacity)
                        .opacity(textOpacity ? 0 : 1)
                        .minimumScaleFactor(0.5)
                    
                    
                    
                    Text("• Our public key is made of N and e. Worry not, we will get to them in a moment.")
                        .font(.system(size: 30))
                        .fontWeight(.semibold)
                        .animation(.easeInOut, value: textOpacity)
                        .opacity(textOpacity ? 0 : 1)
                        .minimumScaleFactor(0.5)
                    
                }.frame(width: UIScreen.main.bounds.width * 0.8, height: UIScreen.main.bounds.height * 0.2, alignment: .leading)
                
                
                Text(processMessage)
                    .font(.system(size: 25))
                    .fontWeight(.semibold)
                    .font(.subheadline)
                    .multilineTextAlignment(.center)
                    .frame(width: UIScreen.main.bounds.width * 0.8, height: UIScreen.main.bounds.height * 0.1 , alignment: .center)
                    .minimumScaleFactor(0.5)
                
                HStack {
                    Text(productInitial)
                        .font(.system(size: 40))
                        .fontWeight(.semibold)
                        .position(location)
                        .gesture(simpleDrag)
                        .frame(width: 50, height: 50)
                        .onChange(of: productInitial) { _ in
                            
                            if productInitial == "6" {
                                location =  CGPoint(x: 70, y: 71)
                            }
                            
                        }.animation(.spring(), value: productInitial)
                    
                    
                    //Done
                    Text("\(productNFinal)")
                        .font(.system(size: 40))
                        .fontWeight(.semibold)
                        .font(.subheadline)
                        .onChange(of: productNFinal) { _ in
                            processMessage = "Now we will calculate Totient which is nothing but (7-1)*(19-1). Precisely drag 6 into 18."
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                                productInitial = "6"
                                productTFinal = "18"
                                totientOpacity = 1.0
                            }
                            
                            
                            withAnimation(.easeInOut(duration: 1.0)) {
                                calculated.toggle()
                            }
                        }
                        .animation(.spring(), value: productNFinal)
                        .offset(offsetNFinal)
                        .animation(.easeInOut, value: textOpacity)
                        .opacity(textOpacity ? 0 : 1)
                    
                }
                
                
                //left
                Text("\(productTFinal)")
                    .font(.system(size: 40))
                    .fontWeight(.semibold)
                    .font(.subheadline)
                    .onChange(of: productTFinal) { _ in
                        processMessage = "Now we will choose E which should be prime, less that Totient T and must not be a factor of N. In our case it will be 29."
                        productInitial = ""
                        
                        eFinal = "E = 29"   
                    }
                    .opacity(totientOpacity)
                
                    .animation(.spring(), value: productTFinal)
                    .offset(x: 30, y: -14)
                
                Text(eFinal)
                    .font(.system(size: 40))
                    .fontWeight(.semibold)
                    .font(.subheadline)
                
                
                    .onChange(of: eFinal, perform: { _ in
                        processMessage = "Awesome job!! You have got the private key which is comprised of N and E. Now let's generate public key D which is (k*T + 1) / E for some integer k = 2. Thus D will be 41"
                        eFinal = "k = 2"
                        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                            processMessage = "Precisely drag k into T to produce a private key"
                        }
                        isDone = true
                    })
                    .animation(.spring(), value: textOpacity)
                    .opacity(eOpacity)
                    .position(eLocation)
                    .gesture(
                        DragGesture()
                            .onChanged({ value in
                                self.eLocation = value.location
                            })
                            .onEnded({ value in
                                self.eLocation = value.location
                                self.key2Scale = 0.0
                                processMessage = "Congratulations. You have generated both keys. Swipe next to encrypt and decrypt message with these keys 🥳"
                            })   
                    )
                
            
                Image("Key1")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 100, height: 50)
                    .animation(.spring(), value: isDone)
                    .onChange(of: isDone, perform: { _ in
                        
                        withAnimation(.easeInOut(duration: 0.25)) {
                            key1Scale = 2.0
                        }
                        
                        withAnimation(.easeInOut(duration: 0.25).delay(0.25)) {
                            key1Scale = 1
                            
                            
                        }
                    })
                    .animation(.spring(), value: key1Scale)
                    .scaleEffect(key1Scale)
                    .position(key1Location)
                    .gesture(
                        
                        DragGesture()
                            .onChanged({ value in
                                withAnimation(.easeInOut(duration: 0.25)) {
                                    key1Scale = 2.0
                                }
                                self.key1Location = value.location
                                
                            })
                            .onEnded({ value in
                                withAnimation(.easeInOut(duration: 0.25)) {
                                    key1Scale = 1.0
                                }
                                self.key1Location = value.location
                            })
                        
                        
                    )
                
                
                Image("Key2")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 100, height: 50)
                    .animation(.spring(), value: key2Scale)
                    .onChange(of: key2Scale, perform: { _ in
                        
                        withAnimation(.easeInOut(duration: 0.25)) {
                            key2Scale = 2.0
                            eOpacity = 0.0
                            totientOpacity = 0.0
                        }
                        
                        withAnimation(.easeInOut(duration: 0.25).delay(0.25)) {
                            key2Scale = 1
                            
                        }
                    })
                    .animation(.spring(), value: key2Scale)
                    .scaleEffect(key2Scale)
                    .position(key2Location)
                    .gesture(
                        
                        DragGesture()
                            .onChanged({ value in
                                withAnimation(.easeInOut(duration: 0.25)) {
                                    key2Scale = 2.0
                                }
                                self.key2Location = value.location
                                
                            })
                            .onEnded({ value in
                                withAnimation(.easeInOut(duration: 0.25)) {
                                    key2Scale = 1.0
                                }
                                self.key2Location = value.location
                            })
                        
                        
                    )
                
                
                
                
                Spacer()
                
                Image("Mac")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 300, height: 200)
                
                
                
                
                
                
                
            }
            .frame(width: UIScreen.main.bounds.width * 0.8, height: UIScreen.main.bounds.height * 0.75)
            .padding()
            .background(.ultraThinMaterial)
            .cornerRadius(40)
            
            
        }
    }
}

struct Working_Previews: PreviewProvider {
    static var previews: some View {
        Working()
        
    }
}
