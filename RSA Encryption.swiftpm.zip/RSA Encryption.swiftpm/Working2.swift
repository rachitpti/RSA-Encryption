//
//  Working2.swift
//  RSA Encryption
//
//  Created by Rachit Prajapati on 25/04/22.
//

import Foundation
import SwiftUI

struct Working2: View {
    
    @State private var showingAlert = false
    @State var isDone : Bool = false
    @State var key1Scale: Double = 0.0
    @State var key2Scale: Double = 0.001
    @State private var key1Location: CGPoint = CGPoint(x: UIScreen.main.bounds.width * 0.4, y: 53)
    @State private var key2Location: CGPoint = CGPoint(x: UIScreen.main.bounds.width * 0.4, y: 0)
    @State private var encryptionState: Bool = false
    @State private var process: String = "Hi"
    @State private var message: String = "Drag the white key which is public key to Hi in order to see the encryption 🔒"
    var body: some View {
        
        ZStack {
            
            VStack(alignment: .center, spacing: 10) {
                
                Text("Let's send a message 'Hi' securely.")
                    .font(.system(size: 40))
                    .fontWeight(.bold)
                    .font(.subheadline)
                    .multilineTextAlignment(.center)
                    .minimumScaleFactor(0.01)
                
                Spacer()
                
                Text(message)
                    .font(.system(size: 30))
                    .fontWeight(.semibold)
                    .font(.subheadline)
                    .multilineTextAlignment(.center)
                    .onChange(of: isDone) { _ in
                        
                        if isDone {
                            message = "Now drag the black key which is private key to decrypt the recieved message which here is 'Hi'."
                        }
                    }
                
                
                
                Image("Key1")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 100, height: 50)
                    .onAppear(perform: {
                        withAnimation(.easeInOut(duration: 0.25)) {
                            key1Scale = 2.0
                        }
                        
                        withAnimation(.easeInOut(duration: 0.25).delay(0.25)) {
                            key1Scale = 1
                        }
                        
                    })
                    .animation(.spring(), value: key1Scale)
                    .scaleEffect(key1Scale)
                    .position(key1Location)
                    .gesture(
                        
                        DragGesture()
                            .onChanged({ value in
                                withAnimation(.easeInOut(duration: 0.25)) {
                                    key1Scale = 2.0
                                }
                                encryptionState = true
                                self.key1Location = value.location
                                
                            })
                            .onEnded({ value in
                                withAnimation(.easeInOut(duration: 0.25)) {
                                    key1Scale = 1.0
                                }
                                self.key1Location = value.location
                            })
                        
                        
                    )
                
                
                Image("Key2")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 100, height: 50)
                
                    .onAppear(perform: {
                        withAnimation(.easeInOut(duration: 0.25)) {
                            key2Scale = 2.0
                            
                        }
                        
                        withAnimation(.easeInOut(duration: 0.25).delay(0.25)) {
                            key2Scale = 1
                        }
                        
                    })
                
                    .animation(.spring(), value: key2Scale)
                    .scaleEffect(key2Scale)
                    .position(key2Location)
                    .gesture(
                        
                        DragGesture()
                            .onChanged({ value in
                                withAnimation(.easeInOut(duration: 0.25)) {
                                    key2Scale = 2.0
                                }
                                self.key2Location = value.location
                                encryptionState = false
                                
                            })
                            .onEnded({ value in
                                withAnimation(.easeInOut(duration: 0.25)) {
                                    key2Scale = 1.0
                                }
                                self.key2Location = value.location
                            })
                        
                        
                    )
                
                Spacer(minLength: 0)
                
                Text(process)
                
                    .font(.system(size: 50))
                    .fontWeight(.bold)
                    .font(.subheadline)
                    .frame(width: UIScreen.main.bounds.width * 0.7, height: 200)
                    .multilineTextAlignment(.center)
                    .onChange(of: encryptionState, perform: { _ in
                        
                        
                        
                        process = "Initializing"
                        
                        if encryptionState {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { [self] in
                                process = ""
                                withAnimation(.easeInOut) {
                                    "H=8, I=9".enumerated().forEach { index, character in
                                        DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.1) {
                                            process += String(character)
                                        }
                                    }
                                    
                                }
                            }
                            

                            DispatchQueue.main.asyncAfter(deadline: .now() + 4.0) { [self] in
                                withAnimation(.easeInOut) {
                                    
                                    process.enumerated().forEach { index, character in
                                        DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.1) {
                                            process.removeLast()
                                        }
                                    }
                                }
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 6.0) { [self] in
                                
                                withAnimation(.easeInOut) {
                                    "c = 89^e mod n (e = 3, n = 133)".enumerated().forEach { index, character in
                                        DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.1) {
                                            process += String(character)
                                        }
                                    }
                                }
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 11.0) { [self] in
                                
                                withAnimation(.easeInOut) {
                                    "c = 89^e mod n (e = 3, n = 133)".enumerated().forEach { index, character in
                                        DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.1) {
                                            process.removeLast()
                                        }
                                    }
                                }
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 16.0) { [self] in
                                withAnimation(.easeInOut(duration: 1.0).delay(3.2)) {
                                    "Encrypted message: 69".enumerated().forEach { index, character in
                                        DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.1) {
                                            process += String(character)
                                        }
                                        isDone = true
                                    }
                                    
                                }
                            }
                            
                        }
                        
                        if encryptionState == false {
                            
                            process = "Decrypting"
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { [self] in
                                withAnimation(.easeInOut) {
                                    process.enumerated().forEach { index, character in
                                        DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.1) {
                                            process.removeLast()
                                        }
                                    }
                                    
                                    
                                }
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) { [self] in
                                withAnimation(.easeInOut) {
                                    "c^d mod n (c = 69, d = 41, n = 133)".enumerated().forEach { index, character in
                                        DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.1) {
                                            process += String(character)
                                        }
                                    }
                                }
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 7.0) { [self] in
                                withAnimation(.easeInOut) {
                                    "c^d mod n (c = 69, d = 41, n = 133)".enumerated().forEach { index, character in
                                        DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.1) {
                                            process.removeLast()
                                        }
                                    }
                                }
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 14.0) { [self] in
                                withAnimation(.easeInOut) {
                                    "Decrypted Message: Hi".enumerated().forEach { index, character in
                                        DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.1) {
                                            process += String(character)
                                        }
                                    }
                                }
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 18.0) { [self] in
                                
                                showingAlert = true
                            }
                        }
                    })
                    .minimumScaleFactor(0.01)
                    .alert(Text("One more thing"), isPresented: $showingAlert) {
                    } message: {
                        Text("In order to revise the concepts there's a short quiz arranged. ")
                    }

                Spacer(minLength: 100)
                
                Image("Mac")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 300, height: 200)
                
            }.frame(width: UIScreen.main.bounds.width * 0.8, height: UIScreen.main.bounds.height * 0.75)
                .padding()
                .background(.ultraThinMaterial)
                .cornerRadius(40)
            
        }
        
        
    }
}

struct Working2_Previews: PreviewProvider {
    static var previews: some View {
        Working2()
    }
}
