//
//  ContentView.swift
//  RSA Encryption
//
//  Created by Rachit Prajapati on 24/04/22.
//

import SwiftUI

/* Following playrground provides the definition of RSA ecryption and gives the context of it's working */
struct ContentView: View {
    
    var body: some View {
        ZStack{ 
            TabView {
                Introduction()
                Introduction2()
                Theory()
                Working()
                Working2()
                Quiz()
            }.tabViewStyle(.page)
           
 
        }.background(
            Image("Background")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .edgesIgnoringSafeArea(.all)
                .frame(width: UIScreen.main.bounds.width,
                       height: UIScreen.main.bounds.height)
        ).padding()

        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
           
    }
}
