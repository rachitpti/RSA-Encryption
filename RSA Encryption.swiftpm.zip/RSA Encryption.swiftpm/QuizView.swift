//
//  QuizView.swift
//  RSA Encryption
//
//  Created by Rachit Prajapati on 25/04/22.
//


import Foundation
import SwiftUI

struct Quiz: View {
    
    var rsaQuiz: [QuizModel] = [
        
        QuizModel(text: "_____ is the process of converting information in one form, to another.", answer: ["Transference", "Encryption", "Protection", "None"], correct: 1),
        
        QuizModel(text: "RSA is named after ____.", answer: [" River, Shamir, Adleman", "Rivest, Shamus, Adleman", " Rivest, Shamir, Adleman", "    Rivest, Shamir, Adlemar"], correct: 2),
        
        QuizModel(text: "Public key encryption uses or creates _____ in its algorithm.", answer: ["Pseudo random number", "Public key", "Private key", "All of the above"], correct: 3)
        
    ]
    
    @State var quizIndex : Int = 0
    @State private var buttonZeroColor: Color = .yellow
    @State private var buttonOneColor: Color = .orange
    @State private var buttonTwoColor: Color = .purple
    @State private var buttonThreeColor: Color = .indigo
    
    var body: some View {
        
        VStack(alignment: .center, spacing: 20){
            if (self.quizIndex < rsaQuiz.count) {
                
                Spacer()
                
                Text(rsaQuiz[self.quizIndex].text)
                    .font(.system(size: 50))
                    .fontWeight(.heavy)
                    .font(.largeTitle)
                    .bold()
                
                Spacer() 
                
                Button(action:{
                    self.buttonAction(n: 0)
                    
                    if rsaQuiz[self.quizIndex].answer[0] == rsaQuiz[self.quizIndex].answer[ rsaQuiz[self.quizIndex].correct] {
                        
                        buttonZeroColor = .green
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            buttonZeroColor = .yellow
                        }
                    } else {
                        buttonZeroColor = .red
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            buttonZeroColor = .yellow
                        }
                    }
                    
                },label: {
                    Text(rsaQuiz[self.quizIndex].answer[0])
                        .foregroundColor(.black)
                        .fontWeight(.semibold)
                        .font(.system(size: 30))
                })
                .frame(width: UIScreen.main.bounds.width * 0.8, height: 60, alignment: .center)
                .background(buttonZeroColor)
                .cornerRadius(20)
                
                
                Button(action:{
                    self.buttonAction(n: 1)
                    
                    if rsaQuiz[self.quizIndex].answer[1] == rsaQuiz[self.quizIndex].answer[ rsaQuiz[self.quizIndex].correct] {
                        
                        buttonOneColor = .green
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            buttonOneColor = .orange
                        }
                    } else {
                        buttonOneColor = .red
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            buttonOneColor = .orange
                        }
                    }
                },label: {
                    Text(rsaQuiz[self.quizIndex].answer[1])
                        .foregroundColor(.black)
                        .fontWeight(.semibold)
                        .font(.system(size: 30))
                })
                .frame(width: UIScreen.main.bounds.width * 0.8, height: 60, alignment: .center)
                .background(buttonOneColor)
                .cornerRadius(20)
                
                
                Button(action:{
                    self.buttonAction(n: 2)
                    
                    if rsaQuiz[self.quizIndex].answer[2] == rsaQuiz[self.quizIndex].answer[ rsaQuiz[self.quizIndex].correct] {
                        
                        buttonTwoColor = .green
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            buttonTwoColor = .purple
                        }
                    } else {
                        buttonTwoColor = .red
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            buttonTwoColor = .purple
                        }
                    }
                    
                },label: {
                    Text(rsaQuiz[self.quizIndex].answer[2])
                        .foregroundColor(.black)
                        .fontWeight(.semibold)
                        .font(.system(size: 30))
                })
                .frame(width: UIScreen.main.bounds.width * 0.8, height: 60, alignment: .center)
                .background(buttonTwoColor)
                .cornerRadius(20)
                
                Button(action:{
                    self.buttonAction(n: 3)
                    if rsaQuiz[self.quizIndex].answer[3] == rsaQuiz[self.quizIndex].answer[ rsaQuiz[self.quizIndex].correct] {
                        
                        buttonThreeColor = .green
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            buttonThreeColor = .indigo
                        }
                    } else {
                        buttonThreeColor = .red
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            buttonThreeColor = .indigo
                        }
                    }
                    
                },label: {
                    Text(rsaQuiz[self.quizIndex].answer[3])
                        .foregroundColor(.black)
                        .fontWeight(.semibold)
                        .font(.system(size: 30))
                })
                .frame(width: UIScreen.main.bounds.width * 0.8, height: 60, alignment: .center)
                .background(buttonThreeColor)
                .cornerRadius(20)
            } else {
                VStack(spacing: 20) {
                    
                    Image("Memoji")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 400, height: 400, alignment: .center)
                    
                    Text("Awesome! You are the best 🎊")
                        .font(.system(size: 40))
                        .fontWeight(.semibold)
                        .font(.subheadline)
                        .multilineTextAlignment(.center)
                    
                    Text("You've switfly encrypted and decrypted a message securely and now having a confident amount of info on RSA encryption.")
                        .font(.system(size: 40))
                        .fontWeight(.semibold)
                        .font(.subheadline)
                        .multilineTextAlignment(.center)
                    
                    Text("Finally, Thank you for viewing my playground ❤️")
                        .font(.system(size: 40))
                        .fontWeight(.semibold)
                        .font(.subheadline)
                        .multilineTextAlignment(.center)
                    
                }
                
            }
            
        }
        .frame(width: UIScreen.main.bounds.width * 0.8, height: UIScreen.main.bounds.height * 0.75)
        .padding()
        .background(.ultraThinMaterial)
        .cornerRadius(40)
        
    }
    
    func buttonAction( n : Int){
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            self.quizIndex = self.quizIndex + 1
        }
    }
    
    
}

struct Quiz_Previews: PreviewProvider {
    static var previews: some View {
        Quiz()
        
    }
}


